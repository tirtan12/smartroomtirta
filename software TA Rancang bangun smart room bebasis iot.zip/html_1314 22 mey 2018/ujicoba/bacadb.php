<?php
include '../dbconnect.php';
$query = mysqli_query ($conn, "SELECT `temperature` FROM `datasuhu` ORDER BY `no_suhu` DESC LIMIT 1");
while($datasuhu_ = mysqli_fetch_array($query)) {
	echo $datasuhu_['temperature'];
}
?>
