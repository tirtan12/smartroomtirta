<!DOCTYPE html>
<html>
<head>
    <script>
    function autoRefresh()
    {
        window.location = window.location.href;
    }
     setInterval('autoRefresh()', 20000);
    </script>
</head>
<body>
<?php
$test="";
?>

<?php
//test_dht11.php
// executes python file to read DHT11 temperature sensor
//and extracts the temperature and humidity values

$temperature=0;
$humidity=0;
$my_pos=0;
$exec_msg="sudo python /var/www/html/ujicoba/AdafruitDHT.py 11 4 2>&1";
$test = shell_exec($exec_msg);

//extracts temperature
$my_pos = strpos($test, "Temp=",0);
$temperature = substr($test, $my_pos+5, 4);
echo "\n ".$temperature."";

//extracts humidity
// ----$my_pos = strpos($test, "Humidity=",$my_pos);
// ----$humidity = substr($test, $my_pos+9, 4);
// ----echo "\n ".$humidity."%";
?>


</body>
</html>
