
<?php

//shell_exec("sudo python /var/www/html/terminal/suhudb.py &");
header("location:ta_tirta/index.php")
?>
