

<?php
shell_exec("sudo motion");


header("location:http://192.168.7.195:8081")
?>


