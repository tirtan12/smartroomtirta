
<!DOCTYPE html>
<html>

<body>

<br><a href=cameraon.php> <img src=http://192.168.7.195:8081/ border=0 width=100%></a>
</body>
</html>
