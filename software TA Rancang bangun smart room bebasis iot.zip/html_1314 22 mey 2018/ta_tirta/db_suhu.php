
    <script>
    function autoRefresh()
    {
        window.location = window.location.href;
    }
     setInterval('autoRefresh()', 15000);
    </script>

<?php
include '../session.php';
?>

<?php
include '../dbconnect.php';
$query = mysqli_query ($conn, "SELECT `temperature` FROM `datasuhu` ORDER BY `id_bacasuhu` DESC LIMIT 1");
while($datasuhu_ = mysqli_fetch_array($query)) {
	echo $datasuhu_['temperature'];
}
?>
