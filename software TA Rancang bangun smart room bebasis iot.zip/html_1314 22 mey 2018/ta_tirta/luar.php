<?php
include '../session.php';
?>
<?php
//shell_exec("sudo motion");
?>
<?php
//include 'home_admin.php';
?>
<?php
//include 'home_admin.php';
?>

<!doctype html>
<html>
<head>
	
	
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
	
<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
<link rel="icon" href="images/icon.png" type="image/x-icon">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SMART ROOM</title>
<link href="css/multiColumnTemplate.css" rel="stylesheet" type="text/css">
<style type="text/css">
body,td,th {
	color: #4CAF50;
  background-images : url("/images/bg1.jpg");
  
}
</style>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<!-- untuk icon atas -->

</head>
<body  background="images/bg1.jpg">
<div class="container">
  <header>
    <div class="primary_header">
      <h1 class="title"> SMART ROOM -Diluar Ruangan-</h1>
      </div>
    <div>
      
	<div class="topnav" id="myTopnav">
  
  <a class="active" href="luar.php">Diluar Ruangan</a>
  <a  href="index.php">Dalam Ruangan</a>
  <!-- <a href="about.php">About</a> -->
  <a href="../logout.php?logout">Logout</a>
		<a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>	
		
		
		
		
		<?php
            if (isset($_POST['lampu_hidup']))
              {
                  shell_exec("sudo python /var/www/html/terminal/lampu_hidup.py");
                  echo( ' <div class="alert alert-info alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Info!</strong> Lampu 1 Berhasil Dinyalakan
  </div>');
              }

                if (isset($_POST['lampu_mati']))
              {
                shell_exec("sudo python /var/www/html/terminal/lampu_mati.py");
                echo( ' <div class="alert alert-danger alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Info!</strong> Lampu 1 Berhasil Dimatikan
  </div>');
              }



              if (isset($_POST['lampu2_hidup']))
             {
              shell_exec("sudo python /var/www/html/terminal/lampu2_hidup.py");
              echo( ' <div class="alert alert-info alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Info!</strong> Lampu 2 Berhasil Dinyalakan
  </div>');
             }
        
              if (isset($_POST['lampu2_mati']))
            {
             shell_exec("sudo python /var/www/html/terminal/lampu2_mati.py");
             echo( ' <div class="alert alert-danger alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Info!</strong> Lampu 2 Berhasil Dimatikan
  </div>');
            }
   



              if (isset($_POST['kipas_hidup']))
            {
              shell_exec("sudo python /var/www/html/terminal/kipas_hidup.py");
              echo( ' <div class="alert alert-info alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Info!</strong> Kipas Berhasil Dinyalakan
  </div>');
            }

              if (isset($_POST['kipas_mati']))
            {
              shell_exec("sudo python /var/www/html/terminal/kipas_mati.py");
              echo( ' <div class="alert alert-danger alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Info!</strong> Kipas Berhasil Dimatikan
  </div>');
            }

              if (isset($_POST['gembok_buka']))
            {
              shell_exec("sudo python /var/www/html/terminal/gembok_buka_asli.py");
              echo( ' <div class="alert alert-info alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Info!</strong> Gembok Telah Terbuka, Silahkan masuk...!!! <strong> jangan lupa kunci kembali pintu </strong>
  </div>');
            }
              if (isset($_POST['gembok_tutup']))
            {
              shell_exec("sudo python /var/www/html/terminal/gembok_tutup.py");
              echo( ' <div class="alert alert-danger alert-dismissible">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Info!</strong> Gembok telah tertutup, <strong> PASTIKAN PINTU TELAH DITUTUP </strong>
  </div>');
            }
?>
		
		
		
		
		
    </div>
	  
	  
	  
	  
	  
</header>
  <section>
    <h2 class="noDisplay">Main Content</h2>
	  
	  <aside class="left_article">
      
		  <p> </p>
		<h1 align="center">CAMERA</h1>
      <!-- <iframe  src="http://192.168.1.1:8085"> </iframe> -->
      <p align="center" <?php include "camera.php";?> </p>
    </aside>
	  
	  
    <article class="right_article">
		<h1 align="center" style="color: #000000">SUHU</h1>
		  <h1 class="suhu" style="color: #0094B9" align="center"> <strong><?php include 'db_suhu.php'; ?> &degC</strong></h1>
		
		
      <!-- <h1 align="center">CAMERA</h1> -->
      <!-- <iframe width="100%" height="500" src="http://192.168.7.202:8081"> </iframe> -->
    </article> 
    
  </section>
<!-- START Mesinnnya-->
		
		<form method="post">
  <div class="row">
			<p></p>
    <div class="columns">
      <p class="thumbnail_align">
			
		   Lampu 
	          
<br>  
<br> <br> <br>  
<br> <br>
		<button class="button" name="lampu_hidup"><img id="myImage" src="images/lighton.png" style="width:45px" height="50px"> <br>ON</button> 
		 
		<button class="button" name="lampu_mati"><img id="myImage" src="images/lightoff.png" style="width:45px" height="50px"> <br>OFF</button> 
		  

      </p>
    </div>
    <div class="columns">
      <p class="thumbnail_align">
			
		   Lampu2 
        
			<br> <br> <br> <br>  
<br> <br>
     
		<button class="button" name="lampu2_hidup"><img id="myImage" src="images/lighton.png" style="width:45px" height="50px"> <br>ON</button>
		
		<button class="button" name="lampu2_mati"><img id="myImage" src="images/lightoff.png" style="width:45px" height="50px"> <br>OFF</button>
		  

      </p>
    </div>
	  
	  <div class="columns">
      <p class="thumbnail_align">
			
		   Kipas
        
			<br> <br> <br> <br>  
<br> <br>
		<button class="button"  name="kipas_hidup"><img id="myImage" src="images/fan.gif" style="width:45px" height="50px"><br>ON</button>
		    
		<button class="button"  name="kipas_mati"><img id="myImage" src="images/fan.png" style="width:45px" height="50px"><br>OFF</button>
		  

      </p>
    </div>
	  
	  <div class="columns">
      <p class="thumbnail_align">
			
		   Gembok 

          

			<br><br> <br> <br>  
<br> <br>
		<button class="button" name="gembok_buka"><img id="myImage" src="images/gembokon.png" style="width:45px" height="50px"><br>
		ON</button>
		 
		<button class="button" name="gembok_tutup"><img id="myImage" src="images/gembokoff.png" style="width:45px" height="50px"><br>OFF</button>
		  

      </p>
    </div>
	  
   <!-- </div> -->
		</form>
		<!-- OFF mechin -->
		
  <div class="row blockDisplay"></div>
  <footer class="secondary_header footer">
    <div class="copyright">&copy;SAID ARIF TIRTANA (Rancang Bangun Prototype Smart Room Berbasis Internet of Thing (IoT))<strong></strong>
    </div>
    <div align="center"> <a href="../logout.php?logout" style="color: #fff" >Logout</a> </div>
  
  </footer>
</div>
</body>
</html>
