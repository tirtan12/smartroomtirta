<!DOCTYPE html>
<html>
<head>
    <script>
    function autoRefresh()
    {
        window.location = window.location.href;
    }
     setInterval('autoRefresh()', 10000);
    </script>
</head>
<body>
<?php
	$suhu = shell_exec("sudo python /var/www/html/terminal/read.py");
	echo $suhu;
	
?>

</body>
</html>

