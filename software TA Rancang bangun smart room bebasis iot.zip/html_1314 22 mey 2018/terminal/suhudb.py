import time
from time import strftime
import os
import Adafruit_DHT
import RPi.GPIO as GPIO
import MySQLdb
import sys

#DB Connection
db = MySQLdb.connect("localhost", "pi", "12021995", "mydb")
cur = db.cursor()

currenttime= 0
DBtime=0
DHTtime=0

pin_suhu = 4
sensor_suhu =Adafruit_DHT.DHT11
pin_fan = 27



def bacasuhu1() :
        hum,temp = Adafruit_DHT.read_retry (sensor_suhu,pin_suhu)
        if hum is not None and temp is not None :
                temp = ' {0:0.1f}'. format (temp)
                hum = ' {0:0.1f}'.format (hum)
                return temp+"@"+hum
        else :
                print 'gagal membaca suhu!'
                return None

def bacasuhu2():
        hum,temp = Adafruit_DHT.read_retry(sensor_suhu,pin_suhu)
        if hum is not None and temp is not None :
                temp = ' {0:0.1f}'. format (temp)
                hum = ' {0:0.1f}'. format (hum)
                return temp
        else:
                print 'gagal baca'
                return None


def GPIOsetup():
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        GPIO.setup(pin_fan, GPIO.OUT)




def kondisi_fan_hidup():
        GPIOsetup()
        GPIO.output(pin_fan,0)

def kondisi_fan_mati():
        GPIOsetup()
        GPIO.output(pin_fan,1)




def main_suhu_fan():
        hasil_baca_sensor = bacasuhu2()
        if float (hasil_baca_sensor) >= 30:
                kondisi_fan_hidup()

                #print hasil_baca_sensor
                print 'Kipas Angin Menyala'

        ###elif float (hasil_baca_sensor) <= 36:
                ###kondisi_fan_mati()
                ###kondisi_lampu_hidup()
                #print hasil_baca_sensor
                ###print 'suhu kurang'

        #else :
                #kondisi_fan_hidup()
                #kondisi_lampu_hidup()
                #print hasil_baca_sensor
                #print 'suhu normal'

def saveDB(temperature,humidity):
        datetimeWrite = (time.strftime("%Y-%m-%d")+time.strftime("%H:%M:%S"))
        dateupdate=datetimeWrite
        #print datetimeWrite
        sql = (""" INSERT INTO datasuhu (waktu,temperature,humidity) VALUES
(%s,%s,%s) """,(dateupdate,temperature,humidity))
        try:
                cur.execute(*sql)
                db.commit ()
                        #print '['+time.strftime ("%H:%M:%S") +'] Update DB Success !!'

        except:
                db.rollback()
                print '['+time.strftime ("%H:%M:%S")+'] Update DB Error !!'
        return dateupdate

try :
        while True:
                main_suhu_fan()
                hasil = bacasuhu1()
                temp = hasil[:hasil.index('@')]
                hum = hasil[hasil.index('@')+1:]
                saveDB(temp,hum)
                print hasil
                time.sleep(5)

except KeyboardInterrupt:
        GPIO.cleanup()
        db.close()
        cur.close()
