import smtplib
import time
from time import strftime
import os
#import MySQLdb
import Adafruit_DHT
import sys
import RPi.GPIO as GPIO


#DB Connection
#db = MySQLdb.connect("localhost", "pi", "12021995", "mydb")
#cur = db.cursor()

#currenttime=0
#DBtime=0
#DHTtime=0
#pin DHT data dan sensordata
sensor = Adafruit_DHT.DHT11 #devinisi adafruit
pin=4 #baca pin sensor

#pin GPIO yg dipakai 
#pemanas = 20
kipas = 27 #baca pin
#kipas_atas = 23
#buzzer = 24

#suhu atur
suhu_atas = 30.0
suhu_bawah = 28.0

#inisialisasi GPIO
def GPIOsetup():
	GPIO.setwarnings(False)
	GPIO.setmode(GPIO.BCM)
	#GPIO.setup(pemanas, GPIO.OUT)
	GPIO.setup(kipas, GPIO.OUT)
	#GPIO.setup(kipas_atas, GPIO.OUT) 
	#GPIO.setup(buzzer, GPIO.OUT)

def bacasuhu():
	hum,temp = Adafruit_DHT.read_retry(sensor, pin)
 	if hum is not None and temp is not None:
		temp = '{0:0.1f}'.format(temp)
		hum =  '{0:0.1f}'.format(hum)
		return temp
	else:
		print 'gagal baca suhu'
		return None

def kondisi_1():
	GPIOsetup()
	#GPIO.output(pemanas, 0)
	GPIO.output(kipas, 0) #hidup 0
	#GPIO.output(kipas_atas, 1)
	#GPIO.output(buzzer, 1)
#	return()
	print("kipas Hidup")

def kondisi_2():
	GPIOsetup()
	#GPIO.output(pemanas, 1)
	GPIO.output(kipas, 1) #mati kipas 1
	#GPIO.output(kipas_atas, 0)
	#GPIO.output(buzzer, 0)
	print("kipas Mati")
	


		
def main():
	while True:	
		data_sensor = bacasuhu()
		#current_date = datetime.datetime.now()
		if float (data_sensor) >= suhu_atas:
			kondisi_1()
			#print ""
			print data_sensor
			#print current_date			
				
		########else:
			#print ""
			########kondisi_2()
			########print data_sensor
 	

try:
	while True:
		#mainn()
		main()
		time.sleep(3)
except KeyboardInterrupt:
    GPIO.cleanup()
    #cur.close()
    #sys.exit(0)






