<?php
ob_start();
session_start();
require_once 'dbconnect.php';

if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}
// select logged in users detail
$res = $conn->query("SELECT * FROM users WHERE id=" . $_SESSION['user']);
$userRow = mysqli_fetch_array($res, MYSQLI_ASSOC);

?>

<head> <link rel="icon" href="/ta_tirta/images/icon.png" type="image/x-icon"> </head>
<!-- DOCTYPE html>
<head>
    
	<title>Hello,<?php echo $userRow['username']; ?></title>
</head>
<body>
<!--<a href="logout.php?logout">

	Keluar </a> -->
</body>
</html>
